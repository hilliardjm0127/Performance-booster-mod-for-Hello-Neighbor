If you downloaded Hello Neighbor from steam folder for "DefaultEngine.ini", the "DefaultGameUserSettings.ini" and "DefaultGame.ini" can be found
at: C:\Program Files (x86)\Steam\steamapps\common\Hello Neighbor\HelloNeighbor\Config

You will need to decompress the folder you downloaded and move the "DefaultEngine.ini", the "DefaultGameUserSettings.ini" and "DefaultGame.ini" to the Config folder.

The folder for "BaseDeviceProfiles.ini" can be found 
at: C:\Program Files (x86)\Steam\steamapps\common\Hello Neighbor\Engine\Config

If you purchased it elsewhere you will have to find the Hello Neighbor folder.

When asked to replace already existing files click agree/yes.



Visual quality is relatively unchanged
No game settings such as gravity, friction, etc. have been changed making this mod
speedrun friendly.